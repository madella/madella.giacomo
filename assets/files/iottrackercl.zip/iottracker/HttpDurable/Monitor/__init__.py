import smtplib, ssl , pyodbc, logging, requests
from shodan import Shodan

def connection():
    server = 'iotttdbserver.database.windows.net'
    database = 'IoTTDB'
    username = 'sqladmin'
    password = 'Superchicche+'
    driver = '{ODBC Driver 17 for SQL Server}'
    connection_string = f"DRIVER={driver};SERVER={server};DATABASE={database};UID={username};PWD={password}"
    try: conn = pyodbc.connect(connection_string)
    except Exception as e: logging.info("Exception on pyodbc connection:",e)
    return conn

def start_monitor(api_key):
    conn = connection()
    cursor = conn.cursor()
    logging.info("Entered in monitor and started connection {}, cursor {}".format(conn,cursor))
    query = f"SELECT  ip_address, id, n_of_vuln, author_id FROM users_ip"
    cursor.execute(query)
    ip_dict = {}
    for row in cursor.fetchall():
        ip=row[0]
        ip_dict[ip] = [ row[1] , row[2] , row[3] ] # ROW1 = ID, ROW2 = N_VULN ROW3= authorid
        list_of_vulns=get_vuln(ip,api_key)
        if (len(list_of_vulns) < 2 and list_of_vulns[0] == 'No vulnerability found!'): lens = 0 
        else: lens = len(list_of_vulns)
        logging.info("Check len list: {} != {}".format(lens, ip_dict[ip][1]))
        if (lens != ip_dict[ip][1]):
            query= f"UPDATE users_ip SET n_of_vuln = '{lens}' WHERE id = '{ip_dict[ip][0]}'"
            cursor.execute(query)
            conn.commit()
            if lens > ip_dict[ip][1]:
                send_mail(cursor,list_of_vulns,ip_dict[ip][2])
            drop_all_from_ip(cursor=cursor,ip_id=ip_dict[ip][0]) # In order to remove No vuln found
            for v in list_of_vulns:
                cvss_score=''
                response = requests.get(f'https://v1.cveapi.com/{v}.json')
                if response.status_code == 200:
                    data = response.json()
                    try: cvss_score = data['impact']['baseMetricV3']['cvssV3']['baseScore']
                    except:
                        try: cvss_score = data['impact']['baseMetricV2']['cvssV2']['baseScore']
                        except: pass
                row =( v, '', ip_dict[ip][0], cvss_score) #HERE ERROR
                table_name = 'users_vulnerabilities'
                query = f"INSERT INTO {table_name} ( name, descriptions, associated_ip_id, cvss_score) VALUES (?, ?, ?, ?)"
                cursor.execute(query, row) 
                conn.commit()
    cursor.close()
    conn.close()
    return True

def get_vuln(ip,api_key):
        api = Shodan(api_key)
        vulnerabilities = []
        try: 
            list_vuln = api.host(ip)
            if 'vulns' in list_vuln:
                if list_vuln['vulns'] is not None:
                    for vuln in list_vuln['vulns']:
                        vulnerabilities.append(vuln)
            else: 
                vulnerabilities=['No vulnerability found!']
        except: vulnerabilities=['No vulnerability found!']
        return vulnerabilities

def drop_all_from_ip(cursor,ip_id):
    query=f"DELETE FROM users_vulnerabilities WHERE associated_ip_id = '{ip_id}'"
    cursor.execute(query)
    cursor.commit()

def send_mail(cursor,vulns,user_id):
    smtp_server = "smtp.gmail.com"
    port = 587  # For starttls
    sender_email = "iothreatracker@gmail.com"
    password = "xzydzwqpijeunrqu"
    # Create a secure SSL context
    context = ssl.create_default_context()
    # Try to log in to server and send email
    try:
        server = smtplib.SMTP(smtp_server,port)
        server.ehlo() # Can be omitted
        server.starttls(context=context) # Secure the connection
        server.ehlo() # Can be omitted
        server.login(sender_email, password)
        #Send email
        query = f"SELECT email FROM auth_user WHERE id = {user_id}"
        cursor.execute(query)
        receiver_email = cursor.fetchall()[0][0]
        subject = "WARNING: NEW VULNERABILITIES ON YOUR DEVICES"
        text = """New vulnerabilities have been detected on your devices:\n\n%s\n\nLog into https://iothreatracker.azurewebsites.net/ with your credentials to obtain more info.""" %  vulns
        message = 'Subject: {}\n\n{}'.format(subject, text)
        # TODO: REIMPLEMENT? server.sendmail(sender_email, receiver_email, message)
        logging.info("e-mail sent to {} with that vulns {}".format(receiver_email,vulns))
    except Exception as e:
        # logging.info any error messages to stdout
        logging.info("Exception occured in sending emali:\n",e)
    finally:
        server.quit() 
        
def main(name: str) -> str:
    return(start_monitor(name))
