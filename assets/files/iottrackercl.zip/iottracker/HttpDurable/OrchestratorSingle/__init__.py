# This function is not intended to be invoked directly. Instead it will be
# triggered by an HTTP starter function.
# Before running this sample, please:
# - create a Durable activity function (default name is "Hello")
# - create a Durable HTTP starter function
# - add azure-functions-durable to requirements.txt
# - run pip install -r requirements.txt

import logging
import json

import azure.functions as func
import azure.durable_functions as df


def orchestrator_function(context: df.DurableOrchestrationContext):
    #TODO: maybe parallelize every ips
    parameters = context.get_input()
    result = yield context.call_activity('SingleRequest',["pHHlgpFt8Ka3Stb5UlTxcaEwciOeF2QM",parameters.get('ip'),parameters.get('username')])
    logging.info("Param is {}, {}."
                 .format(
                     parameters.get('ip'),
                     parameters.get('username'))
                )

    return [result]#, result2, result3]

main = df.Orchestrator.create(orchestrator_function)