import pyodbc, logging, requests
from shodan import Shodan

def connection():
    server = 'iotttdbserver.database.windows.net'
    database = 'IoTTDB'
    username = 'sqladmin'
    password = 'Superchicche+'
    driver = '{ODBC Driver 17 for SQL Server}'
    connection_string = f"DRIVER={driver};SERVER={server};DATABASE={database};UID={username};PWD={password}"
    try: conn = pyodbc.connect(connection_string)
    except Exception as e: logging.info("Exception on pyodbc connection:",e)
    return conn

def start_monitor(list):
    api_key=list[0]
    ipi=''.join(list[1])
    user=list[2]
    conn = connection()
    cursor = conn.cursor()
    query = f"SELECT id FROM auth_user WHERE username= '{user}'"
    cursor.execute(query)
    try: id=cursor.fetchall()[0][0]
    except Exception as e:id=0;logging.info("ID NOT WORKING {}".format(e))
    logging.info("ID from user retrived= {}".format(id))
    conn = connection()
    cursor = conn.cursor()
    query = f"SELECT ip_address, id, n_of_vuln, author_id FROM users_ip WHERE ip_address = '{ipi}' and author_id = '{id}' "
    cursor.execute(query)
    ip_dict = {}
    for row in cursor.fetchall():
        # logging.info("Inside Fetchall")
        # logging.info("IP_SINGLE_CHECK",row)
        ip=row[0]
        ip_dict[ip] = [ row[1] , row[2] , row[3] ] # ROW1 = ID, ROW2 = N_VULN ROW3= authorid
        list_of_vulns=get_vuln(ip,api_key)
        if (len(list_of_vulns) < 2 and list_of_vulns[0] == 'No vulnerability found!'): lens = 0 
        else: lens = len(list_of_vulns)
        # logging.info("Check len list: {} != {}".format(lens, ip_dict[ip][1]))
        if (lens != ip_dict[ip][1]):
            query= f"UPDATE users_ip SET n_of_vuln = '{lens}' WHERE id = '{ip_dict[ip][0]}'"
            cursor.execute(query)
            conn.commit()
            for v in list_of_vulns:
                cvss_score=''
                response = requests.get(f'https://v1.cveapi.com/{v}.json')
                if response.status_code == 200:
                    data = response.json()
                    try: cvss_score = data['impact']['baseMetricV3']['cvssV3']['baseScore']
                    except:
                        try: cvss_score = data['impact']['baseMetricV2']['cvssV2']['baseScore']
                        except: pass
                row =( v, '', ip_dict[ip][0], cvss_score) #HERE ERROR
                table_name = 'users_vulnerabilities'
                query = f"INSERT INTO {table_name} ( name, descriptions, associated_ip_id, cvss_score) VALUES (?, ?, ?, ?)"
                cursor.execute(query, row) 
                conn.commit()
                # logging.info("Vulnerability written")
    cursor.close()
    conn.close()
    return True

def get_vuln(ip,api_key):
        api = Shodan(api_key)
        vulnerabilities = []
        try: 
            list_vuln = api.host(ip)
            if 'vulns' in list_vuln:
                if list_vuln['vulns'] is not None:
                    for vuln in list_vuln['vulns']:
                        vulnerabilities.append(vuln)
            else: 
                vulnerabilities=['No vulnerability found!']
        except: vulnerabilities=['No vulnerability found!']
        return vulnerabilities
        
def main(name: list) -> str:
    return(start_monitor(name))
