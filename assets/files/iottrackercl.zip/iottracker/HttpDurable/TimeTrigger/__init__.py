 
import logging, signal

import azure.functions as func
import azure.durable_functions as df
    
def main(timer: func.TimerRequest) -> func.HttpResponse:
    client = df.DurableOrchestrationClient("durableClientTT")
    instance_id = client.start_new("Orchestrator", None, None)

    logging.info(f"Started orchestration, ID = '{instance_id},{timer}'.")

    return client.create_check_status_response(instance_id)

def handle_sigterm(signum, frame):
    # Custom signal handler for SIGTERM
    # Add any cleanup or termination logic here
    exit(0)

# Register the signal handler
signal.signal(signal.SIGTERM, handle_sigterm)