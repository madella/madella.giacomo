import smtplib, ssl
from email.message import EmailMessage

smtp_server = "smtp.gmail.com"
port = 587  # For starttls
sender_email = "iothreatracker@gmail.com"
password = "xzydzwqpijeunrqu"


# Create a secure SSL context
context = ssl.create_default_context()

# Try to log in to server and send email
try:
    server = smtplib.SMTP(smtp_server,port)
    server.ehlo() # Can be omitted
    server.starttls(context=context) # Secure the connection
    server.ehlo() # Can be omitted
    server.login(sender_email, password)

    #Send email
    
    vulns = "CWA-404, CWA-104"
    receiver_email = "emanuele.eusepi@studio.unibo.it"
    subject = "WARNING: NEW VULNERABILITIES ON YOUR DEVICES"
    text = """New vulnerabilities have been detected on your devices:

%s

Log into https://iothreatracker.azurewebsites.net/ with your credentials to obtain more info.""" %  vulns
    message = 'Subject: {}\n\n{}'.format(subject, text)

    server.sendmail(sender_email, receiver_email, message)
    print("e-mail sent to {}".format(receiver_email))
except Exception as e:
    # Print any error messages to stdout
    print(e)
finally:
    server.quit() 