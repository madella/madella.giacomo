import datetime
import logging
import smtplib, ssl
from shodan import Shodan
import signal
import pyodbc

import azure.functions as func

def connection():
    server = 'iotttdbserver.database.windows.net'
    database = 'IoTTDB'
    username = 'sqladmin'
    password = 'Superchicche+'
    driver = '{ODBC Driver 17 for SQL Server}'
    connection_string = f"DRIVER={driver};SERVER={server};DATABASE={database};UID={username};PWD={password}"
    try: conn = pyodbc.connect(connection_string)
    except Exception as e: logging.info("Exception on pyodbc connection:",e)
    return conn

def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()
    # if mytimer.past_due:
    #     logging.info('The timer is past due!')
    start_monitor('pHHlgpFt8Ka3Stb5UlTxcaEwciOeF2QM') #TODO: higly insecure!!!!!
    logging.info('Python timer trigger function ran at %s', utc_timestamp)

def handle_sigterm(signum, frame):
    # Custom signal handler for SIGTERM
    # Add any cleanup or termination logic here
    exit(0)

# Register the signal handler
signal.signal(signal.SIGTERM, handle_sigterm)

def start_monitor(api_key):
    # Azure
    conn = connection()
    cursor = conn.cursor()
    logging.info("DB connection {}, cursor {}".format(conn,cursor))
    # Query selection of all infos
    query = "SELECT ip_address FROM users_ip"
    cursor.execute(query)
    rows = cursor.fetchall()
    ip_addresses = [row[0] for row in rows]
    table_name = 'users_ip'
    column_id = 'id'
    column_key = 'ip_address'
    column_author_id = 'author_id'
    column_value = 'n_of_vuln'
    query = f"SELECT  {column_key}, {column_id}, {column_value}, {column_author_id} FROM {table_name}"
    cursor.execute(query)
    ip_dict = {}
    for row in cursor.fetchall():
        ip_dict[row[0]] = [ row[1] , row[2] , row[3] ] # ROW1 = ID, ROW2 = N_VULN ROW3= authorid
    logging.info("ip found in db: {}".format(ip_dict))

    logging.info("{}] FROM ASYNC".format(api_key))
    for ip in ip_addresses:
        list_of_vulns=get_vuln(ip,api_key)
        # logging.info("CHECK len list: {} != {}".format(len(list_of_vulns),ip_dict[ip][1]))
        if (len(list_of_vulns) != ip_dict[ip][1]): #selct from where ip.n_of_vulns è un parametro!! dovete fare una nuova query selct n_of_vulns o qualcosa di simile--->FATTO ;)
            table_name = 'users_ip'
            new_len=len(list_of_vulns)
            query= f"UPDATE {table_name} SET n_of_vuln = '{new_len}' WHERE id = '{ip_dict[ip][0]}'"
            cursor.execute(query)
            conn.commit()
            #Send mail
            if len(list_of_vulns) > ip_dict[ip][1]:
                send_mail(cursor,list_of_vulns,ip_dict[ip][2]) #TODO: reimplement
            drop_all_from_ip(cursor=cursor,ip_id=ip_dict[ip][0])
            for v in list_of_vulns:
                row =( v, '', ip_dict[ip][0])
                table_name = 'users_vulnerabilities'
                query = f"INSERT INTO {table_name} ( name, descriptions, associated_ip_id) VALUES (?, ?, ?)"
                cursor.execute(query, row)
                conn.commit()
                # print("VULN SAVED SUCCESFULLYs")
        else: pass #sprint("SKIPPED")
    cursor.close()
    conn.close()

def get_vuln(ip,api_key):
        api = Shodan(api_key)
        vulnerabilities = []
        try: 
            list_vuln = api.host(ip)
            if 'vulns' in list_vuln:
                if list_vuln['vulns'] is not None:
                    for vuln in list_vuln['vulns']:
                        vulnerabilities.append(vuln)
            else: 
                vulnerabilities=['No vulnerability found!']
        except: vulnerabilities=['No vulnerability found!']
        return vulnerabilities

def drop_all_from_ip(cursor,ip_id):
    query=f"DELETE FROM users_vulnerabilities WHERE associated_ip_id = '{ip_id}'"
    cursor.execute(query)
    cursor.commit()


def send_mail(cursor,vulns,user_id):
    smtp_server = "smtp.gmail.com"
    port = 587  # For starttls
    sender_email = "iothreatracker@gmail.com"
    password = "xzydzwqpijeunrqu"
    # Create a secure SSL context
    context = ssl.create_default_context()
    # Try to log in to server and send email
    try:
        server = smtplib.SMTP(smtp_server,port)
        server.ehlo() # Can be omitted
        server.starttls(context=context) # Secure the connection
        server.ehlo() # Can be omitted
        server.login(sender_email, password)
        #Send email
        query = f"SELECT email FROM auth_user WHERE id = {user_id}"
        cursor.execute(query)
        receiver_email = cursor.fetchall()[0][0]
        subject = "WARNING: NEW VULNERABILITIES ON YOUR DEVICES"
        text = """New vulnerabilities have been detected on your devices:\n\n%s\n\nLog into https://iothreatracker.azurewebsites.net/ with your credentials to obtain more info.""" %  vulns
        message = 'Subject: {}\n\n{}'.format(subject, text)
        server.sendmail(sender_email, receiver_email, message)
        logging.info("e-mail sent to {} with that vulns {}".format(receiver_email,vulns))
    except Exception as e:
        # Print any error messages to stdout
        logging.info("Exception occured in sending emali:\n",e)
    finally:
        server.quit() 
        
#send_mail(azure_db_connector.connection().cursor(),'Sticazzi',1)
main(None)
# TODO: reinsert working API: pHHlgpFt8Ka3Stb5UlTxcaEwciOeF2QM i changed the API in order to 
# avoid useless request