import requests

cve_code = 'CVE-2022-0778'
api_url = f'https://v1.cveapi.com/{cve_code}.json'
response = requests.get(api_url)

if response.status_code == 200:
    data = response.json()
    cvss_score = data['impact']['baseMetricV3']['cvssV3']['baseScore']
    print(f"CVSS (v3) score for {cve_code}: {cvss_score}")
else:
    print("Failed to retrieve CVSS score")