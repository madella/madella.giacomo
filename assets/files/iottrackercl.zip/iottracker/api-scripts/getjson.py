import requests

url = "https://iotttfunction.azurewebsites.net/runtime/webhooks/durabletask/instances/466e08d6c1e34203a05ad5b3f8503e27?taskHub=iotttfunction&connection=Storage&code=snigMQGBHt1inKiozSRHLRQ8eSvYi6K1Ik-nb6qt96yHAzFuRE-r1A=="
response = requests.get(url)
json_data = response.json()
print(json_data)
