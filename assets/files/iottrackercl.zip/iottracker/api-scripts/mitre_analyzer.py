from mitrecve import crawler


f = open("vuln.dict" , "r")
for x in f:
  print(x)
  cve_simple = crawler.get_cve_detail(x)
f.close()