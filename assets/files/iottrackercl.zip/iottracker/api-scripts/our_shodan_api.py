from shodan import Shodan
class ApiShodan:
    def __init__(self, api_key):
        self.api = Shodan(api_key)
        

    def get_vulnerabilities(self, ip):
        list_vuln = self.api.host(ip)
        vulnerabilities = []
        if 'vulns' in list_vuln:
            if list_vuln['vulns'] is not None:
                for vuln in list_vuln['vulns']:
                    vulnerabilities.append(vuln)
        return vulnerabilities


#api = ApiShodan('E584xLec4TT25RKRjt9JkRiPW91iZop6') #fede
# xvkx8cUzUaTO6966Xr3jdqstStrD4TPN ema
# tipo v4YpsPUJ3wjDxEqywwu6aF5OZKWj8kik
api = ApiShodan('pHHlgpFt8Ka3Stb5UlTxcaEwciOeF2QM')
ip = '172.232.70.71'
#ip= '20.185.32.163' no vulns!
#ip='45.79.132.133'
vulnerabilities = api.get_vulnerabilities(ip)

# Stampa le vulnerabilità
for vulnerability in vulnerabilities:
    print(vulnerability)