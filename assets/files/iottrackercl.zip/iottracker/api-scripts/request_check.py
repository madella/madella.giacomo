import requests


# r= requests.get("https://iotthreatrackerapp2.azurewebsites.net/status/",)

hhttptrigger="https://iotttfunction.azurewebsites.net/api/orchestrators/Orchestrator?"
r2=requests.get(hhttptrigger,params={'ip':f'100.42.144.4'})
#print(r2.text)
print(r2.text.split()[3].strip()[:-1])
response = requests.get(r2.text.split()[3][1:-2])
json_data = response.json()
print(json_data)
