import shodan
api = shodan.Shodan('E584xLec4TT25RKRjt9JkRiPW91iZop6')

hosts = api.host([
    '8.8.8.8',
    '8.8.4.4',
])

for info in hosts:
    # Each record in the "hosts" list is what an individual IP lookup returns
    print(info['ip_str'])
