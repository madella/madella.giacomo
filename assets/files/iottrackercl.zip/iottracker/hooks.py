import os
print(os.environ.get('MONITOR_RUNNING'))
os.environ['MONITOR_RUNNING'] = 'True'
