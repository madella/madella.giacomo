from django.shortcuts import render
import os,markdown
import logging
from django.http import HttpResponse

infos =[{
    'author':'Le superchicche',
    'title':'iot-monitor'
}]
title= 'iot-monitor'


# Create your views here.
def home(request):
    parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    readme_path = os.path.join(parent_dir, 'README.md')
    
    with open(readme_path, 'r',encoding="utf-8") as readme_file:
        readme_content = readme_file.read()

    html_content = markdown.markdown(readme_content,output_format='html')

    context = {'readme_content': html_content}

    #log?#
    logger = logging.getLogger("logger_name")
    logger.warning("this will be tracked")
    for num in range(5):
        logger.warning(f"Log Entry - {num}")
    #log?#
    return render(request,"main/home.html",context)

def status(request):
    response = HttpResponse('Health Check')
    response.status_code = 200  # sample status code
    return response

def about(request):
    parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    fede_path = os.path.join(parent_dir, 'main/static/fede.png')
    max_path = os.path.join(parent_dir, 'main/static/max.png')
    ema_path = os.path.join(parent_dir, 'main/static/ema.png')
    jack_path = os.path.join(parent_dir, 'main/static/jack.png')
    context = {
        'fede_url': fede_path,
        'max_url': max_path,
        'ema_url': ema_path,
        'jack_url': jack_path
    }
    return render(request,"main/about.html", context)
