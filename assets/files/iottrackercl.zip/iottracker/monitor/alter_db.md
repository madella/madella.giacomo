DELETE FROm [dbo].[users_vulnerabilities]
UPDATE users_ip SET n_of_vuln = 0;