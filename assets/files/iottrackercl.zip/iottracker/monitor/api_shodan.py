import requests 
from shodan import Shodan

class ApiShodan:
    def __init__(self, api_key):
        self.api = Shodan(api_key)
        # print("STARTED APISHODAN v1",api_key)
        
    def get_vulnerabilities(self, ip):
        vulnerabilities = []
        try: 
            list_vuln = self.api.host(ip)
            if 'vulns' in list_vuln:
                if list_vuln['vulns'] is not None:
                    for vuln in list_vuln['vulns']:
                        vulnerabilities.append(vuln)
            else: 
                vulnerabilities=['No vulnerability found!']
        except: vulnerabilities=['No vulnerability found!']
        print(vulnerabilities)
        return vulnerabilities

    
    def list_to_queryset(model, data):
        from django.db.models.base import ModelBase

        if not isinstance(model, ModelBase):
            raise ValueError(
                "%s must be Model" % model
            )
        if not isinstance(data, list):
            raise ValueError(
                "%s must be List Object" % data
            )

        pk_list = [obj.pk for obj in data]
        return model.objects.filter(pk__in=pk_list)
