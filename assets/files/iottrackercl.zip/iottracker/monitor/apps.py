import sys
from django.apps import AppConfig

class MyAppConfig(AppConfig):
    name = 'monitor'