import sys,time
from shodan import Shodan
from users import models as u_mod

import signal
import time

def handle_sigterm(signum, frame):
    # Custom signal handler for SIGTERM
    # Add any cleanup or termination logic here
    exit(0)

# Register the signal handler
signal.signal(signal.SIGTERM, handle_sigterm)

def start_monitor(api_key):
    sleep_time=60
    while(True):
        print("{}] FROM ASYNC".format(api_key))
        ips = u_mod.IP.objects.all()
        for ip in ips:
            count=0
            list_of_vulns=get_vuln(ip.convert(),api_key)
            print(list_of_vulns)
            print("DEBUG: LEN",len(list_of_vulns))
            if (len(list_of_vulns) != ip.n_of_vuln):
                ip.n_of_vuln=len(list_of_vulns)
                ip.save()
                for v in list_of_vulns:
                    count+=1
                    vulnerability = u_mod.Vulnerabilities()
                    vulnerability.associated_ip = ip
                    vulnerability.name = v
                    vulnerability.descriptions=''
                    try:
                        vulnerability.save()
                    except Exception as e: pass
            else: print("SKIPPED")
        print("monitor is going to sleep for {}s".format(sleep_time))
        time.sleep(sleep_time)
def get_vuln(ip,api_key):
        api = Shodan(api_key)
        vulnerabilities = []
        try: 
            list_vuln = api.host(ip)
            if 'vulns' in list_vuln:
                if list_vuln['vulns'] is not None:
                    for vuln in list_vuln['vulns']:
                        vulnerabilities.append(vuln)
            else: 
                vulnerabilities=['No vulnerability found!']
        except: vulnerabilities=['No vulnerability found!']
        return vulnerabilities