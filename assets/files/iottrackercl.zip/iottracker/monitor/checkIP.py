def is_valid_ip(ip):
    parts = ip.split(".")
    if len(parts) != 4:
        return False

    for part in parts:
        if not part.isdigit() or int(part) < 0 or int(part) > 255:
            return False
    if parts[0] == '10':
        return False

    if parts[0] == '172' and 16 <= int(parts[1]) <= 31:
        return False

    if parts[0] == '192' and parts[1] == '168':
        return False
    return True