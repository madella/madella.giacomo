
from django.shortcuts import render,redirect
from users import models as u_mod
from users import views as u_view
from . import api_shodan
import requests

def update(request):
    http_trigger="https://iotttfunction.azurewebsites.net/api/orchestrators/Orchestrator?"
    r2=requests.get(http_trigger)
    return u_view.asyncR(request, r2.text.split()[3][1:-2])

def single_update(request,ip_single):
    #OLD http_trigger="https://iotttfunction.azurewebsites.net/api/orchestrators/OrchestratorSingle?"
    http_trigger= "https://functionappiottt.azurewebsites.net/api/orchestrators/OrchestratorSingle?"
    print(request.user,type(f"{request.user}"))
    r2=requests.get(http_trigger,params={'ip': f"{ip_single}",'username': f"{request.user}"})
    return u_view.asyncR(request, r2.text.split()[3][1:-2])

def old_single_update(request,ip_single):
    sk = u_mod.shodan_key.objects.get(author=request.user)
    shodan=api_shodan.ApiShodan(sk.key)
    all_vulns={}
    ip=u_mod.IP.objects.filter(ip_address=ip_single).filter(author=request.user)[0]
    list_of_vulns=shodan.get_vulnerabilities(ip.convert())
    print(len(list_of_vulns),ip.n_of_vuln)
    all_vulns[ip]=list_of_vulns
    if (len(list_of_vulns) < 2 and list_of_vulns[0] == 'No vulnerability found!'): lens = 0 
    else: lens = len(list_of_vulns)
    print("{}] winth {} (!= {}?) vulns as : {}".format(ip,lens,ip.n_of_vuln,list_of_vulns))
    if (lens != ip.n_of_vuln):
        u_mod.Vulnerabilities.objects.filter(associated_ip=ip).delete()
        for v in list_of_vulns:
            vulnerability = u_mod.Vulnerabilities()
            vulnerability.associated_ip = ip
            vulnerability.name = v
            vulnerability.descriptions=''
            api_url = f'https://v1.cveapi.com/{v}.json'
            response = requests.get(api_url)
            if response.status_code == 200:
                data = response.json()
                try:
                    vulnerability.cvss_score = data['impact']['baseMetricV3']['cvssV3']['baseScore']
                    print(f"CVSS (v3) score for {v}: {vulnerability.cvss_score}")
                except:
                    try:
                        vulnerability.cvss_score = data['impact']['baseMetricV2']['cvssV2']['baseScore']
                        print(f"CVSS (v2) score for {v}: {vulnerability.cvss_score}")
                    except:pass

            vulnerability.save()
        ip.n_of_vuln=lens
        ip.save()
    print("BEFORE REDIRECT")
    return redirect("users-profile",)

def update_old(request):
    _,_=shodan_request(request.user)
    return redirect("users-profile")

def shodan_request(user):
    #TODO: MAYBE request to our Trigger!
    ips = u_mod.IP.objects.filter(author=user)
    sk = u_mod.shodan_key.objects.get(author=user)
    shodan=api_shodan.ApiShodan(sk.key)
    # u_mod.Vulnerabilities.objects.all().delete()
    all_vulns={}
    for ip in ips:
        list_of_vulns=shodan.get_vulnerabilities(ip.convert())
        print("HERE:",list_of_vulns)
        all_vulns[ip]=list_of_vulns
        if (len(list_of_vulns) < 2 and list_of_vulns[0] == 'No vulnerability found!'): lens = 0 
        else: lens = len(list_of_vulns)
        print("{}] winth {} (!= {}?) vulns as : {}".format(ip,lens,ip.n_of_vuln,list_of_vulns))
        if (lens != ip.n_of_vuln):
            u_mod.Vulnerabilities.objects.filter(associated_ip=ip).delete()
            for v in list_of_vulns:
                vulnerability = u_mod.Vulnerabilities()
                vulnerability.associated_ip = ip
                vulnerability.name = v
                vulnerability.descriptions=''
                response = requests.get(f'https://v1.cveapi.com/{v}.json')
                if response.status_code == 200:
                    data = response.json()
                    try:
                        vulnerability.cvss_score = data['impact']['baseMetricV3']['cvssV3']['baseScore']
                    except:
                        try:
                            vulnerability.cvss_score = data['impact']['baseMetricV2']['cvssV2']['baseScore']
                        except: pass
                vulnerability.save();print("Vuln saved")
                # except Exception as e: print('Exepted')
            ip.n_of_vuln=len(list_of_vulns)
            ip.save()
    return ips,all_vulns