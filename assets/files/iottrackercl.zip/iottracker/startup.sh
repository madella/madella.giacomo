#!/bin/bash
redis-server &
docker-compose up &