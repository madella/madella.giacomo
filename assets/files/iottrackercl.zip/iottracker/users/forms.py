from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from . import models

class Register(UserCreationForm):
    email= forms.EmailField()
    #shodan_key = forms.CharField(label="Your shodan key", max_length=50)
    class Meta:
        model=User
        fields = ['username','email','password1']


class IP(forms.ModelForm):
    ip_address = forms.CharField(label="Insert IP", max_length=15)
    class Meta:
        model=models.IP
        fields = ['ip_address']

