from django.db import models
from django.urls import reverse
from django.contrib.auth.models import User,AbstractUser


class shodan_key(models.Model):
  key = models.CharField(max_length=50,unique=False)
  author = models.ForeignKey(User,auto_created=True,on_delete=models.CASCADE)
  class Meta:
      unique_together = ('key', 'author')

class IP(models.Model):
  ip_address = models.CharField(max_length=15,unique=False)
  author = models.ForeignKey(User,auto_created=True,on_delete=models.CASCADE)
  n_of_vuln= models.IntegerField(unique=False)

  def convert(self):
    return ''.join(self.ip_address)
  class Meta:
      unique_together = ('ip_address', 'author')

class Vulnerabilities(models.Model):
    name = models.CharField(max_length=100,unique=False)
    descriptions=models.CharField(max_length=50)
    associated_ip = models.ForeignKey(IP, on_delete=models.CASCADE)
    cvss_score = models.FloatField(null=True)
    class Meta:
      unique_together = ('name', 'associated_ip')