from django.test import SimpleTestCase
from django.urls import reverse, resolve
from users.views import profile
import json

class TestUrls(SimpleTestCase):

    def test_user_profile_url_is_resolved(self):

        url = reverse('users-profile') #url name
        print(resolve(url))
        self.assertEquals(resolve(url).func, profile) #checking the use of the correct function to create the view