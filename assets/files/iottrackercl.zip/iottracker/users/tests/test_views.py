from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
import json

class TestViews(TestCase):

    def setUp(self):
        self.client = Client()
        self.register_url = reverse('users-register')
        self.login_url = reverse('users-login')


    def test_users_POST_new_user(self):
        
        form_data = {
            'username': 'testuser',
            'email' : 'example@gmail.com',
            'shodan_key' : 'exampleShodanKey',
            'password1' : 'testpassword',
            'password2' : 'testpassword'
        }

        response = self.client.post(self.register_url, form_data)
        self.assertEqual(response.status_code, 302)  # Check if it's a redirect

        # Checks user's creation
        self.assertTrue(User.objects.filter(username='testuser').exists())

        user = User.objects.get(username='testuser')
        self.assertIsNotNone(user)
        self.assertEqual(user.username, 'testuser')

    def test_login(self):
        # mock user creation
        username = 'testuser'
        password = 'testpassword'
        user = User.objects.create_user(username=username, password=password)

        # POST form data
        form_data = {
            'username': username,
            'password': password,
        }

        response = self.client.post(self.login_url, form_data)
        self.assertEqual(response.status_code, 302)  # Checks if the response is a redirect

        # Checks if the user is authenticated correctly
        self.assertTrue(response.wsgi_request.user.is_authenticated)

        # Checks if the authenticated user matches the created test user
        self.assertEqual(response.wsgi_request.user.username, username)
