from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from . import forms
from . import models
from monitor import checkIP
from monitor import views as m_v

def register(request):
    if request.method == "POST":
        form=forms.Register(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f"Account {username} has been created, please login")
            sk=models.shodan_key()
            sk.key = "xvkx8cUzUaTO6966Xr3jdqstStrD4TPN"
            user = models.User.objects.get(username=username)
            sk.author = user
            try:
                sk.save()
            except: print("Error: NOT SAVED PK")
            return redirect("users-login")
    else:
        form= forms.Register()
    return render(request, 'users/register.html', {'form':form})

    
@login_required()
def profile(request):
    if request.method == "POST":
        form=forms.IP(request.POST)
        if form.is_valid():
            ip = form.cleaned_data['ip_address']
            if models.IP.objects.filter(author=request.user).filter(ip_address=ip).exists(): # Return error since ip already exists
                messages.error(request,f"Already saved IP")
                return redirect('users-profile')       
            if checkIP.is_valid_ip(ip): # Save ip in DB
                instance = form.save(commit=False) 
                instance.author = request.user
                instance.n_of_vuln = -1
                instance.save()
                return m_v.single_update(request,ip)
            else: messages.error(request,f"Invalid IP")
    else:
        form= forms.IP()
    ips,vulns,labels,values,data_list,vulnsPerIP=manageContext(request)
    return render(request, 'users/profile.html',{'ips':ips , 'form':form ,'vulns':vulns,'labels':labels, 'values':values, 'data_list': data_list, 'values_bar':vulnsPerIP})

def asyncR(request,site):
    form= forms.IP()
    ips,vulns,labels,values,data_list,vulnsPerIP=manageContext(request)
    return render(request, 'users/profile.html',{'ips':ips , 'form':form ,'vulns':vulns, 'site':site,'labels':labels, 'values':values, 'data_list': data_list, 'values_bar':vulnsPerIP})

def manageContext(request):
    ips = models.IP.objects.filter(author=request.user)
    vulns={}
    values = {}
    vulnsPerIP = []
    countHigh = 0; countMed = 0; countLow = 0
    print(ips)
    for ip in ips.iterator():
        vulns[ip]=models.Vulnerabilities.objects.filter(associated_ip=ip)
        print(ip,vulns[ip])
        if (len(vulns[ip]) > 1): vulnsPerIP.append(len(vulns[ip]))
        else: vulnsPerIP.append(0)
        for v in vulns[ip]:
            if (v.cvss_score is not None):
                if(v.cvss_score >= 7): countHigh+=1
                elif (v.cvss_score >= 4): countMed+=1
                elif (v.cvss_score >= 0.5): countLow+=1
                    
    data_list = [countLow, countMed, countHigh]
    labels = ['Low', 'Medium', 'High']
    return ips,vulns,labels,values,data_list,vulnsPerIP

